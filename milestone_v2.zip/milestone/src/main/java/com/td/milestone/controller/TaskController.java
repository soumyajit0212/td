package com.td.milestone.controller;

import com.td.milestone.model.TaskMaster;
import com.td.milestone.repo.TaskMasterRepository;
import jakarta.persistence.Id;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.lang.reflect.Field;

@RestController
@RequestMapping("/tasks")
public class TaskController {
    private final TaskMasterRepository repo;
    public TaskController(TaskMasterRepository repo) { this.repo = repo; }

    @GetMapping
    public List<TaskMaster> list() { return repo.findAll(); }

    @PostMapping
    public TaskMaster create(@RequestBody TaskMaster body) {
        return repo.save(body);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TaskMaster> get(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<TaskMaster> update(@PathVariable Long id, @RequestBody TaskMaster body) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        setIdIfPossible(body, id);
        return ResponseEntity.ok(repo.save(body));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private static void setIdIfPossible(Object entity, Long id) {
        try {
            for (Field f : entity.getClass().getDeclaredFields()) {
                if (f.isAnnotationPresent(Id.class)) {
                    f.setAccessible(true);
                    f.set(entity, id);
                    return;
                }
            }
        } catch (Exception ignored) { }
    }
}
