package com.td.milestone.model;

import jakarta.persistence.*;

@Entity
@Table(name = "org_master", schema = "milestone")
public class OrgMaster {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "org_name", nullable = false)
    private String orgName;

    @Column(name = "description")
    private String description;

    public Long getOrgId() { return orgId; }
    public void setOrgId(Long orgId) { this.orgId = orgId; }
    public String getOrgName() { return orgName; }
    public void setOrgName(String orgName) { this.orgName = orgName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
