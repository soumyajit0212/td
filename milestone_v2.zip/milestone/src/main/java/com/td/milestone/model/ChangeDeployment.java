package com.td.milestone.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "change_deployment", schema = "milestone")
public class ChangeDeployment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "change_id")
    private Long changeId;

    @Column(name = "change_type")
    private String changeType;

    @ManyToOne @JoinColumn(name = "env_id")
    private EnvironmentMaster environment;

    @ManyToOne @JoinColumn(name = "task_id")
    private TaskMaster task;

    @Column(name = "planned_deploy_date")
    private LocalDate plannedDeployDate;

    @Column(name = "actual_deploy_date")
    private LocalDate actualDeployDate;

    @Column(name = "version_info", unique = true)
    private String versionInfo;

    @Column(name = "manifest_file")
    private String manifestFile;

    @Column(name = "jira_ref")
    private String jiraRef;

    @Column(name = "change_ref")
    private String changeRef;

    public Long getChangeId() { return changeId; }
    public void setChangeId(Long changeId) { this.changeId = changeId; }
    public String getChangeType() { return changeType; }
    public void setChangeType(String changeType) { this.changeType = changeType; }
    public EnvironmentMaster getEnvironment() { return environment; }
    public void setEnvironment(EnvironmentMaster environment) { this.environment = environment; }
    public TaskMaster getTask() { return task; }
    public void setTask(TaskMaster task) { this.task = task; }
    public LocalDate getPlannedDeployDate() { return plannedDeployDate; }
    public void setPlannedDeployDate(LocalDate plannedDeployDate) { this.plannedDeployDate = plannedDeployDate; }
    public LocalDate getActualDeployDate() { return actualDeployDate; }
    public void setActualDeployDate(LocalDate actualDeployDate) { this.actualDeployDate = actualDeployDate; }
    public String getVersionInfo() { return versionInfo; }
    public void setVersionInfo(String versionInfo) { this.versionInfo = versionInfo; }
    public String getManifestFile() { return manifestFile; }
    public void setManifestFile(String manifestFile) { this.manifestFile = manifestFile; }
    public String getJiraRef() { return jiraRef; }
    public void setJiraRef(String jiraRef) { this.jiraRef = jiraRef; }
    public String getChangeRef() { return changeRef; }
    public void setChangeRef(String changeRef) { this.changeRef = changeRef; }
}
