package com.td.milestone.model;

import jakarta.persistence.*;

@Entity
@Table(name = "task_dependencies", schema = "milestone", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"task_id", "dependent_task"})
})
public class TaskDependency {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "mapping_id")
    private Long mappingId;

    @ManyToOne @JoinColumn(name = "task_id", nullable = false)
    private TaskMaster task;

    @ManyToOne @JoinColumn(name = "dependent_task", nullable = false)
    private TaskMaster dependentTask;

    @ManyToOne @JoinColumn(name = "project_id", nullable = false)
    private ProjectMaster project;

    public Long getMappingId() { return mappingId; }
    public void setMappingId(Long mappingId) { this.mappingId = mappingId; }
    public TaskMaster getTask() { return task; }
    public void setTask(TaskMaster task) { this.task = task; }
    public TaskMaster getDependentTask() { return dependentTask; }
    public void setDependentTask(TaskMaster dependentTask) { this.dependentTask = dependentTask; }
    public ProjectMaster getProject() { return project; }
    public void setProject(ProjectMaster project) { this.project = project; }
}
