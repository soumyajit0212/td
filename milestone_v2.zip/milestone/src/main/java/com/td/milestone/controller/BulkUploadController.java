package com.td.milestone.controller;

import com.td.milestone.model.*;
import com.td.milestone.repo.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/bulk")
public class BulkUploadController {

    private final OrgMasterRepository orgRepo;
    private final UserAccountRepository userRepo;
    private final ProjectMasterRepository projectRepo;
    private final TaskMasterRepository taskRepo;
    private final TaskDependencyRepository depRepo;
    private final EnvironmentMasterRepository envRepo;
    private final ChangeDeploymentRepository changeRepo;
    private final MilestoneMasterRepository milestoneRepo;
    private final CodePackageRepository pkgRepo;

    public BulkUploadController(OrgMasterRepository orgRepo, UserAccountRepository userRepo,
                                ProjectMasterRepository projectRepo, TaskMasterRepository taskRepo,
                                TaskDependencyRepository depRepo, EnvironmentMasterRepository envRepo,
                                ChangeDeploymentRepository changeRepo, MilestoneMasterRepository milestoneRepo,
                                CodePackageRepository pkgRepo) {
        this.orgRepo = orgRepo; this.userRepo = userRepo; this.projectRepo = projectRepo; this.taskRepo = taskRepo;
        this.depRepo = depRepo; this.envRepo = envRepo; this.changeRepo = changeRepo; this.milestoneRepo = milestoneRepo;
        this.pkgRepo = pkgRepo;
    }

    @PostMapping("/orgs")
    public ResponseEntity<String> uploadOrgs(@RequestParam("file") MultipartFile file) throws Exception {
        List<OrgMaster> list = new ArrayList<>();
        try (InputStream in = file.getInputStream(); Workbook wb = new XSSFWorkbook(in)) {
            Sheet sh = wb.getSheetAt(0);
            for (int i=1; i<=sh.getLastRowNum(); i++) {
                Row r = sh.getRow(i); if (r==null) continue;
                OrgMaster o = new OrgMaster();
                o.setOrgName(getString(r,0));
                o.setDescription(getString(r,1));
                list.add(o);
            }
        }
        orgRepo.saveAll(list);
        return ResponseEntity.ok("Inserted " + list.size() + " orgs");
    }

    @PostMapping("/users")
    public ResponseEntity<String> uploadUsers(@RequestParam("file") MultipartFile file) throws Exception {
        List<UserAccount> list = new ArrayList<>();
        try (InputStream in = file.getInputStream(); Workbook wb = new XSSFWorkbook(in)) {
            Sheet sh = wb.getSheetAt(0);
            for (int i=1; i<=sh.getLastRowNum(); i++) {
                Row r = sh.getRow(i); if (r==null) continue;
                UserAccount u = new UserAccount();
                u.setPassword(getString(r,0));
                Long orgId = getLong(r,1);
                if (orgId != null) orgRepo.findById(orgId).ifPresent(u::setOrg);
                u.setEmail(getString(r,2));
                u.setName(getString(r,3));
                u.setRole(getString(r,4));
                list.add(u);
            }
        }
        userRepo.saveAll(list);
        return ResponseEntity.ok("Inserted " + list.size() + " users");
    }

    @PostMapping("/projects")
    public ResponseEntity<String> uploadProjects(@RequestParam("file") MultipartFile file) throws Exception {
        List<ProjectMaster> list = new ArrayList<>();
        try (InputStream in = file.getInputStream(); Workbook wb = new XSSFWorkbook(in)) {
            Sheet sh = wb.getSheetAt(0);
            for (int i=1; i<=sh.getLastRowNum(); i++) {
                Row r = sh.getRow(i); if (r==null) continue;
                ProjectMaster p = new ProjectMaster();
                Long orgId = getLong(r,0); if (orgId != null) orgRepo.findById(orgId).ifPresent(p::setOrg);
                p.setProjectName(getString(r,1));
                p.setDescription(getString(r,2));
                p.setStartDate(getDate(r,3));
                p.setEndDate(getDate(r,4));
                p.setStatus(getString(r,5));
                list.add(p);
            }
        }
        projectRepo.saveAll(list);
        return ResponseEntity.ok("Inserted " + list.size() + " projects");
    }

    @PostMapping("/tasks")
    public ResponseEntity<String> uploadTasks(@RequestParam("file") MultipartFile file) throws Exception {
        List<TaskMaster> list = new ArrayList<>();
        try (InputStream in = file.getInputStream(); Workbook wb = new XSSFWorkbook(in)) {
            Sheet sh = wb.getSheetAt(0);
            for (int i=1; i<=sh.getLastRowNum(); i++) {
                Row r = sh.getRow(i); if (r==null) continue;
                TaskMaster t = new TaskMaster();
                Long projectId = getLong(r,0); if (projectId!=null) projectRepo.findById(projectId).ifPresent(t::setProject);
                t.setTaskName(getString(r,1));
                t.setDescription(getString(r,2));
                t.setStartDate(getDate(r,3));
                t.setEndDate(getDate(r,4));
                t.setTaskType(getString(r,5));
                Long assigned = getLong(r,6); if (assigned!=null) userRepo.findById(assigned).ifPresent(t::setAssignedTo);
                t.setJiraRef(getString(r,7));
                t.setComments(getString(r,8));
                t.setCommentDate(getDate(r,9));
                list.add(t);
            }
        }
        taskRepo.saveAll(list);
        return ResponseEntity.ok("Inserted " + list.size() + " tasks");
    }

    @PostMapping("/task-dependencies")
    public ResponseEntity<String> uploadDeps(@RequestParam("file") MultipartFile file) throws Exception {
        List<TaskDependency> list = new ArrayList<>();
        try (InputStream in = file.getInputStream(); Workbook wb = new XSSFWorkbook(in)) {
            Sheet sh = wb.getSheetAt(0);
            for (int i=1; i<=sh.getLastRowNum(); i++) {
                Row r = sh.getRow(i); if (r==null) continue;
                TaskDependency d = new TaskDependency();
                Long taskId = getLong(r,0); if (taskId!=null) taskRepo.findById(taskId).ifPresent(d::setTask);
                Long depId = getLong(r,1); if (depId!=null) taskRepo.findById(depId).ifPresent(d::setDependentTask);
                Long projId = getLong(r,2); if (projId!=null) projectRepo.findById(projId).ifPresent(d::setProject);
                list.add(d);
            }
        }
        depRepo.saveAll(list);
        return ResponseEntity.ok("Inserted " + list.size() + " task dependencies");
    }

    @PostMapping("/environments")
    public ResponseEntity<String> uploadEnvs(@RequestParam("file") MultipartFile file) throws Exception {
        List<EnvironmentMaster> list = new ArrayList<>();
        try (InputStream in = file.getInputStream(); Workbook wb = new XSSFWorkbook(in)) {
            Sheet sh = wb.getSheetAt(0);
            for (int i=1; i<=sh.getLastRowNum(); i++) {
                Row r = sh.getRow(i); if (r==null) continue;
                EnvironmentMaster e = new EnvironmentMaster();
                Long orgId = getLong(r,0); if (orgId!=null) orgRepo.findById(orgId).ifPresent(e::setOrg);
                e.setEnvName(getString(r,1));
                e.setEnvType(getString(r,2));
                e.setUsername(getString(r,3));
                e.setHostname(getString(r,4));
                e.setDatabaseUrl(getString(r,5));
                e.setSchemaName(getString(r,6));
                e.setPassword(getString(r,7));
                list.add(e);
            }
        }
        envRepo.saveAll(list);
        return ResponseEntity.ok("Inserted " + list.size() + " environments");
    }

    @PostMapping("/changes")
    public ResponseEntity<String> uploadChanges(@RequestParam("file") MultipartFile file) throws Exception {
        List<ChangeDeployment> list = new ArrayList<>();
        try (InputStream in = file.getInputStream(); Workbook wb = new XSSFWorkbook(in)) {
            Sheet sh = wb.getSheetAt(0);
            for (int i=1; i<=sh.getLastRowNum(); i++) {
                Row r = sh.getRow(i); if (r==null) continue;
                ChangeDeployment c = new ChangeDeployment();
                c.setChangeType(getString(r,0));
                Long envId = getLong(r,1); if (envId!=null) envRepo.findById(envId).ifPresent(c::setEnvironment);
                Long taskId = getLong(r,2); if (taskId!=null) taskRepo.findById(taskId).ifPresent(c::setTask);
                c.setPlannedDeployDate(getDate(r,3));
                c.setActualDeployDate(getDate(r,4));
                c.setVersionInfo(getString(r,5));
                c.setManifestFile(getString(r,6));
                c.setJiraRef(getString(r,7));
                c.setChangeRef(getString(r,8));
                list.add(c);
            }
        }
        changeRepo.saveAll(list);
        return ResponseEntity.ok("Inserted " + list.size() + " changes");
    }

    @PostMapping("/milestones")
    public ResponseEntity<String> uploadMilestones(@RequestParam("file") MultipartFile file) throws Exception {
        List<MilestoneMaster> list = new ArrayList<>();
        try (InputStream in = file.getInputStream(); Workbook wb = new XSSFWorkbook(in)) {
            Sheet sh = wb.getSheetAt(0);
            for (int i=1; i<=sh.getLastRowNum(); i++) {
                Row r = sh.getRow(i); if (r==null) continue;
                MilestoneMaster m = new MilestoneMaster();
                Long orgId = getLong(r,0); if (orgId!=null) orgRepo.findById(orgId).ifPresent(m::setOrg);
                m.setMilestoneName(getString(r,1));
                m.setTargetDate(getDate(r,2));
                m.setNextDate(getDate(r,3));
                m.setVersionInfo(getString(r,4));
                m.setIsLatest(getString(r,5));
                m.setComments(getString(r,6));
                String dep = getString(r,7);
                if (dep != null && !dep.isEmpty()) {
                    String[] parts = dep.split(",");
                    Integer[] arr = new Integer[parts.length];
                    for (int j=0;j<parts.length;j++) {
                        try { arr[j] = Integer.parseInt(parts[j].trim()); } catch (Exception e) { arr[j]=null; }
                    }
                    m.setDependentTasks(arr);
                }
                list.add(m);
            }
        }
        milestoneRepo.saveAll(list);
        return ResponseEntity.ok("Inserted " + list.size() + " milestones");
    }

    @PostMapping("/code-packages")
    public ResponseEntity<String> uploadCodePackages(@RequestParam("file") MultipartFile file) throws Exception {
        List<CodePackage> list = new ArrayList<>();
        try (InputStream in = file.getInputStream(); Workbook wb = new XSSFWorkbook(in)) {
            Sheet sh = wb.getSheetAt(0);
            for (int i=1; i<=sh.getLastRowNum(); i++) {
                Row r = sh.getRow(i); if (r==null) continue;
                CodePackage p = new CodePackage();
                String ver = getString(r,0);
                if (ver != null) changeRepo.findByVersionInfo(ver).ifPresent(p::setChangeDeployment);
                p.setManifestFile(getString(r,1));
                p.setObjectName(getString(r,2));
                p.setObjectType(getString(r,3));
                Long env = getLong(r,4); if (env!=null) envRepo.findById(env).ifPresent(p::setDeployedEnv);
                list.add(p);
            }
        }
        pkgRepo.saveAll(list);
        return ResponseEntity.ok("Inserted " + list.size() + " code packages");
    }

    private static String getString(Row r, int idx) {
        Cell c = r.getCell(idx); if (c==null) return null;
        if (c.getCellType() == CellType.STRING) return c.getStringCellValue();
        if (c.getCellType() == CellType.NUMERIC) return String.valueOf((long)c.getNumericCellValue());
        if (c.getCellType() == CellType.BOOLEAN) return String.valueOf(c.getBooleanCellValue());
        return null;
    }

    private static Long getLong(Row r, int idx) {
        Cell c = r.getCell(idx); if (c==null) return null;
        if (c.getCellType() == CellType.NUMERIC) return (long)c.getNumericCellValue();
        if (c.getCellType() == CellType.STRING) { try { return Long.parseLong(c.getStringCellValue()); } catch (Exception ignored) {} }
        return null;
    }

    private static java.time.LocalDate getDate(Row r, int idx) {
        Cell c = r.getCell(idx); if (c==null) return null;
        if (c.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(c)) {
            return c.getLocalDateTimeCellValue().toLocalDate();
        }
        if (c.getCellType() == CellType.STRING) {
            try { return LocalDate.parse(c.getStringCellValue()); } catch (Exception ignored) {}
        }
        return null;
    }
}
