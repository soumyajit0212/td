package com.td.milestone.dto;

public class LoginRequest {
    public String usernameOrEmail;
    public String password;
}
