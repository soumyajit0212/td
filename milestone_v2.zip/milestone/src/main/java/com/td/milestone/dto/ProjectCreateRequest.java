package com.td.milestone.dto;

import java.time.LocalDate;
import java.util.List;

public class ProjectCreateRequest {
    public Long orgId;
    public String projectName;
    public String description;
    public LocalDate startDate;
    public LocalDate endDate;
    public String status;
    public List<TaskCreateRequest> tasks;

    public static class TaskCreateRequest {
        public String taskName;
        public String description;
        public LocalDate startDate;
        public LocalDate endDate;
        public String taskType;
        public Long assignedToUserId;
        public String jiraRef;
        public String comments;
        public LocalDate commentDate;
    }
}
