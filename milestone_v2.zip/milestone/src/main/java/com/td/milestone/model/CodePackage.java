package com.td.milestone.model;

import jakarta.persistence.*;

@Entity
@Table(name = "code_packages", schema = "milestone")
public class CodePackage {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "code_id")
    private Long codeId;

    @ManyToOne
    @JoinColumn(name = "code_version", referencedColumnName = "version_info")
    private ChangeDeployment changeDeployment;

    @Column(name = "manifest_file")
    private String manifestFile;

    @Column(name = "object_name")
    private String objectName;

    @Column(name = "object_type")
    private String objectType;

    @ManyToOne @JoinColumn(name = "deployed_env")
    private EnvironmentMaster deployedEnv;

    public Long getCodeId() { return codeId; }
    public void setCodeId(Long codeId) { this.codeId = codeId; }
    public ChangeDeployment getChangeDeployment() { return changeDeployment; }
    public void setChangeDeployment(ChangeDeployment changeDeployment) { this.changeDeployment = changeDeployment; }
    public String getManifestFile() { return manifestFile; }
    public void setManifestFile(String manifestFile) { this.manifestFile = manifestFile; }
    public String getObjectName() { return objectName; }
    public void setObjectName(String objectName) { this.objectName = objectName; }
    public String getObjectType() { return objectType; }
    public void setObjectType(String objectType) { this.objectType = objectType; }
    public EnvironmentMaster getDeployedEnv() { return deployedEnv; }
    public void setDeployedEnv(EnvironmentMaster deployedEnv) { this.deployedEnv = deployedEnv; }
}
