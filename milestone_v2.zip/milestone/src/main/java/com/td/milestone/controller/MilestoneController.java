package com.td.milestone.controller;

import com.td.milestone.model.MilestoneMaster;
import com.td.milestone.repo.MilestoneMasterRepository;
import jakarta.persistence.Id;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.lang.reflect.Field;

@RestController
@RequestMapping("/milestones")
public class MilestoneController {
    private final MilestoneMasterRepository repo;
    public MilestoneController(MilestoneMasterRepository repo) { this.repo = repo; }

    @GetMapping
    public List<MilestoneMaster> list() { return repo.findAll(); }

    @PostMapping
    public MilestoneMaster create(@RequestBody MilestoneMaster body) {
        return repo.save(body);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MilestoneMaster> get(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<MilestoneMaster> update(@PathVariable Long id, @RequestBody MilestoneMaster body) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        setIdIfPossible(body, id);
        return ResponseEntity.ok(repo.save(body));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private static void setIdIfPossible(Object entity, Long id) {
        try {
            for (Field f : entity.getClass().getDeclaredFields()) {
                if (f.isAnnotationPresent(Id.class)) {
                    f.setAccessible(true);
                    f.set(entity, id);
                    return;
                }
            }
        } catch (Exception ignored) { }
    }
}
