package com.td.milestone.controller;

import com.td.milestone.dto.ProjectCreateRequest;
import com.td.milestone.model.*;
import com.td.milestone.repo.*;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/projects")
public class ProjectController {

    private final ProjectMasterRepository projectRepo;
    private final OrgMasterRepository orgRepo;
    private final TaskMasterRepository taskRepo;
    private final UserAccountRepository userRepo;

    public ProjectController(ProjectMasterRepository projectRepo, OrgMasterRepository orgRepo,
                             TaskMasterRepository taskRepo, UserAccountRepository userRepo) {
        this.projectRepo = projectRepo; this.orgRepo = orgRepo; this.taskRepo = taskRepo; this.userRepo = userRepo;
    }

    @GetMapping
    public List<ProjectMaster> list() { return projectRepo.findAll(); }

    @PostMapping
    public ResponseEntity<ProjectMaster> create(@Valid @RequestBody ProjectCreateRequest req) {
        OrgMaster org = (req.orgId != null) ? orgRepo.findById(req.orgId).orElse(null) : null;
        ProjectMaster p = new ProjectMaster();
        p.setOrg(org);
        p.setProjectName(req.projectName);
        p.setDescription(req.description);
        p.setStartDate(req.startDate);
        p.setEndDate(req.endDate);
        p.setStatus(req.status);
        ProjectMaster saved = projectRepo.save(p);

        if (req.tasks != null) {
            for (ProjectCreateRequest.TaskCreateRequest t : req.tasks) {
                TaskMaster task = new TaskMaster();
                task.setProject(saved);
                task.setTaskName(t.taskName);
                task.setDescription(t.description);
                task.setStartDate(t.startDate);
                task.setEndDate(t.endDate);
                task.setTaskType(t.taskType);
                if (t.assignedToUserId != null) {
                    userRepo.findById(t.assignedToUserId).ifPresent(task::setAssignedTo);
                }
                task.setJiraRef(t.jiraRef);
                task.setComments(t.comments);
                task.setCommentDate(t.commentDate);
                taskRepo.save(task);
            }
        }
        return ResponseEntity.created(URI.create("/projects/" + saved.getProjectId())).body(saved);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProjectMaster> get(@PathVariable Long id) {
        return projectRepo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!projectRepo.existsById(id)) return ResponseEntity.notFound().build();
        projectRepo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
