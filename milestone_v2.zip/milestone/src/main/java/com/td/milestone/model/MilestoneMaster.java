package com.td.milestone.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Table(name = "milestone_master", schema = "milestone")
public class MilestoneMaster {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "mil_id")
    private Long milId;

    @ManyToOne @JoinColumn(name = "org_id")
    private OrgMaster org;

    @Column(name = "milestone_name", nullable = false)
    private String milestoneName;

    @Column(name = "target_date")
    private LocalDate targetDate;

    @Column(name = "next_date")
    private LocalDate nextDate;

    @Column(name = "version_info")
    private String versionInfo;

    @Column(name = "is_latest")
    private String isLatest;

    @Column(name = "comments")
    private String comments;

    // Store task IDs as array in Postgres, map as String for simplicity at JPA layer
    @Column(name = "dependent_tasks", columnDefinition = "integer[]")
    private Integer[] dependentTasks;

    public Long getMilId() { return milId; }
    public void setMilId(Long milId) { this.milId = milId; }
    public OrgMaster getOrg() { return org; }
    public void setOrg(OrgMaster org) { this.org = org; }
    public String getMilestoneName() { return milestoneName; }
    public void setMilestoneName(String milestoneName) { this.milestoneName = milestoneName; }
    public LocalDate getTargetDate() { return targetDate; }
    public void setTargetDate(LocalDate targetDate) { this.targetDate = targetDate; }
    public LocalDate getNextDate() { return nextDate; }
    public void setNextDate(LocalDate nextDate) { this.nextDate = nextDate; }
    public String getVersionInfo() { return versionInfo; }
    public void setVersionInfo(String versionInfo) { this.versionInfo = versionInfo; }
    public String getIsLatest() { return isLatest; }
    public void setIsLatest(String isLatest) { this.isLatest = isLatest; }
    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }
    public Integer[] getDependentTasks() { return dependentTasks; }
    public void setDependentTasks(Integer[] dependentTasks) { this.dependentTasks = dependentTasks; }
}
