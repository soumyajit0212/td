package com.td.milestone.model;

import jakarta.persistence.*;

@Entity
@Table(name = "environment_master", schema = "milestone")
public class EnvironmentMaster {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "env_id")
    private Long envId;

    @ManyToOne @JoinColumn(name = "org_id")
    private OrgMaster org;

    @Column(name = "env_name", nullable = false)
    private String envName;

    @Column(name = "env_type")
    private String envType;

    @Column(name = "username")
    private String username;

    @Column(name = "hostname")
    private String hostname;

    @Column(name = "database_url")
    private String databaseUrl;

    @Column(name = "schema_name")
    private String schemaName;

    @Column(name = "password")
    private String password;

    public Long getEnvId() { return envId; }
    public void setEnvId(Long envId) { this.envId = envId; }
    public OrgMaster getOrg() { return org; }
    public void setOrg(OrgMaster org) { this.org = org; }
    public String getEnvName() { return envName; }
    public void setEnvName(String envName) { this.envName = envName; }
    public String getEnvType() { return envType; }
    public void setEnvType(String envType) { this.envType = envType; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getHostname() { return hostname; }
    public void setHostname(String hostname) { this.hostname = hostname; }
    public String getDatabaseUrl() { return databaseUrl; }
    public void setDatabaseUrl(String databaseUrl) { this.databaseUrl = databaseUrl; }
    public String getSchemaName() { return schemaName; }
    public void setSchemaName(String schemaName) { this.schemaName = schemaName; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}
