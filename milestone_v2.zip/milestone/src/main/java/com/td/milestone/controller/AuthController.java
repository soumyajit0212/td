package com.td.milestone.controller;

import com.td.milestone.dto.LoginRequest;
import com.td.milestone.dto.LoginResponse;
import com.td.milestone.model.UserAccount;
import com.td.milestone.repo.UserAccountRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping
public class AuthController {

    private final UserAccountRepository userRepo;

    public AuthController(UserAccountRepository userRepo) {
        this.userRepo = userRepo;
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest req) {
        if (req == null || req.usernameOrEmail == null || req.password == null) {
            return ResponseEntity.badRequest().body(new LoginResponse(false, null, null, "Missing credentials"));
        }

        // Try email first
        Optional<UserAccount> userOpt = userRepo.findByEmail(req.usernameOrEmail);

        // If not found and the input looks numeric, try by userId
        if (userOpt.isEmpty() && req.usernameOrEmail.matches("\\d+")) {
            try {
                Long id = Long.parseLong(req.usernameOrEmail);
                userOpt = userRepo.findById(id);
            } catch (NumberFormatException ignored) {}
        }

        if (userOpt.isEmpty()) {
            return ResponseEntity.status(401).body(new LoginResponse(false, null, null, "User not found"));
        }

        UserAccount user = userOpt.get();
        // NOTE: For demo purposes, comparing plaintext. Replace with BCrypt for production.
        if (!user.getPassword().equals(req.password)) {
            return ResponseEntity.status(401).body(new LoginResponse(false, null, null, "Invalid password"));
        }
        return ResponseEntity.ok(new LoginResponse(true, user.getUserId(), user.getRole(), "Authenticated"));
    }
}
