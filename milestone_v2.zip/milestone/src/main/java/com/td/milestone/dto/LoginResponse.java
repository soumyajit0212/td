package com.td.milestone.dto;

public class LoginResponse {
    public boolean success;
    public Long userId;
    public String role;
    public String message;

    public LoginResponse(boolean success, Long userId, String role, String message) {
        this.success = success;
        this.userId = userId;
        this.role = role;
        this.message = message;
    }
}
