package com.td.milestone.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "task_master", schema = "milestone")
public class TaskMaster {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "task_id")
    private Long taskId;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private ProjectMaster project;

    @Column(name = "task_name", nullable = false)
    private String taskName;

    @Column(name = "description")
    private String description;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "task_type")
    private String taskType;

    @ManyToOne
    @JoinColumn(name = "assigned_to")
    private UserAccount assignedTo;

    @Column(name = "jira_ref")
    private String jiraRef;

    @Column(name = "comments")
    private String comments;

    @Column(name = "comment_date")
    private LocalDate commentDate;

    public Long getTaskId() { return taskId; }
    public void setTaskId(Long taskId) { this.taskId = taskId; }
    public ProjectMaster getProject() { return project; }
    public void setProject(ProjectMaster project) { this.project = project; }
    public String getTaskName() { return taskName; }
    public void setTaskName(String taskName) { this.taskName = taskName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public String getTaskType() { return taskType; }
    public void setTaskType(String taskType) { this.taskType = taskType; }
    public UserAccount getAssignedTo() { return assignedTo; }
    public void setAssignedTo(UserAccount assignedTo) { this.assignedTo = assignedTo; }
    public String getJiraRef() { return jiraRef; }
    public void setJiraRef(String jiraRef) { this.jiraRef = jiraRef; }
    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }
    public LocalDate getCommentDate() { return commentDate; }
    public void setCommentDate(LocalDate commentDate) { this.commentDate = commentDate; }
}
