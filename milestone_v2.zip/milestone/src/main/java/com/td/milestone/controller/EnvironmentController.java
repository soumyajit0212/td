package com.td.milestone.controller;

import com.td.milestone.model.EnvironmentMaster;
import com.td.milestone.repo.EnvironmentMasterRepository;
import jakarta.persistence.Id;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.lang.reflect.Field;

@RestController
@RequestMapping("/environments")
public class EnvironmentController {
    private final EnvironmentMasterRepository repo;
    public EnvironmentController(EnvironmentMasterRepository repo) { this.repo = repo; }

    @GetMapping
    public List<EnvironmentMaster> list() { return repo.findAll(); }

    @PostMapping
    public EnvironmentMaster create(@RequestBody EnvironmentMaster body) {
        return repo.save(body);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EnvironmentMaster> get(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<EnvironmentMaster> update(@PathVariable Long id, @RequestBody EnvironmentMaster body) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        setIdIfPossible(body, id);
        return ResponseEntity.ok(repo.save(body));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private static void setIdIfPossible(Object entity, Long id) {
        try {
            for (Field f : entity.getClass().getDeclaredFields()) {
                if (f.isAnnotationPresent(Id.class)) {
                    f.setAccessible(true);
                    f.set(entity, id);
                    return;
                }
            }
        } catch (Exception ignored) { }
    }
}
