-- Create schema
CREATE SCHEMA IF NOT EXISTS milestone;

-- Organizations
CREATE TABLE IF NOT EXISTS milestone.org_master (
  org_id SERIAL PRIMARY KEY,
  org_name VARCHAR(200) NOT NULL,
  description TEXT
);

-- Users
CREATE TABLE IF NOT EXISTS milestone.users (
  userid SERIAL PRIMARY KEY,
  password VARCHAR(255) NOT NULL,
  org_id INTEGER REFERENCES milestone.org_master(org_id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  email VARCHAR(255) UNIQUE,
  name VARCHAR(255),
  role VARCHAR(100)
);

-- Projects
CREATE TABLE IF NOT EXISTS milestone.project_master (
  project_id SERIAL PRIMARY KEY,
  org_id INTEGER REFERENCES milestone.org_master(org_id) ON DELETE SET NULL,
  project_name VARCHAR(255) NOT NULL,
  description TEXT,
  start_date DATE,
  end_date DATE,
  status VARCHAR(100)
);

-- Tasks
CREATE TABLE IF NOT EXISTS milestone.task_master (
  task_id SERIAL PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES milestone.project_master(project_id) ON DELETE CASCADE,
  task_name VARCHAR(255) NOT NULL,
  description TEXT,
  start_date DATE,
  end_date DATE,
  task_type VARCHAR(100),
  assigned_to INTEGER REFERENCES milestone.users(userid) ON DELETE SET NULL,
  jira_ref VARCHAR(255),
  comments TEXT,
  comment_date DATE
);

-- Task dependencies
CREATE TABLE IF NOT EXISTS milestone.task_dependencies (
  mapping_id SERIAL PRIMARY KEY,
  task_id INTEGER NOT NULL REFERENCES milestone.task_master(task_id) ON DELETE CASCADE,
  dependent_task INTEGER NOT NULL REFERENCES milestone.task_master(task_id) ON DELETE CASCADE,
  project_id INTEGER NOT NULL REFERENCES milestone.project_master(project_id) ON DELETE CASCADE,
  UNIQUE(task_id, dependent_task)
);

-- Environments
CREATE TABLE IF NOT EXISTS milestone.environment_master (
  env_id SERIAL PRIMARY KEY,
  org_id INTEGER REFERENCES milestone.org_master(org_id) ON DELETE SET NULL,
  env_name VARCHAR(200) NOT NULL,
  env_type VARCHAR(100),
  username VARCHAR(200),
  hostname VARCHAR(255),
  database_url VARCHAR(500),
  schema_name VARCHAR(200),
  password VARCHAR(255)
);

-- Change deployment
CREATE TABLE IF NOT EXISTS milestone.change_deployment (
  change_id SERIAL PRIMARY KEY,
  change_type VARCHAR(100),
  env_id INTEGER REFERENCES milestone.environment_master(env_id) ON DELETE SET NULL,
  task_id INTEGER REFERENCES milestone.task_master(task_id) ON DELETE SET NULL,
  planned_deploy_date DATE,
  actual_deploy_date DATE,
  version_info VARCHAR(200) UNIQUE,
  manifest_file VARCHAR(500),
  jira_ref VARCHAR(255),
  change_ref VARCHAR(255)
);

-- Milestones
CREATE TABLE IF NOT EXISTS milestone.milestone_master (
  mil_id SERIAL PRIMARY KEY,
  org_id INTEGER REFERENCES milestone.org_master(org_id) ON DELETE SET NULL,
  milestone_name VARCHAR(255) NOT NULL,
  target_date DATE,
  next_date DATE,
  version_info VARCHAR(200),
  is_latest CHAR(1) CHECK (is_latest IN ('Y','N')),
  comments TEXT,
  dependent_tasks INTEGER[] -- array of task IDs
);

-- Code packages
CREATE TABLE IF NOT EXISTS milestone.code_packages (
  code_id SERIAL PRIMARY KEY,
  code_version VARCHAR(200) REFERENCES milestone.change_deployment(version_info) ON DELETE SET NULL,
  manifest_file VARCHAR(500),
  object_name VARCHAR(255),
  object_type VARCHAR(100),
  deployed_env INTEGER REFERENCES milestone.environment_master(env_id) ON DELETE SET NULL
);
