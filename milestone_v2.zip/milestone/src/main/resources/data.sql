INSERT INTO milestone.org_master (org_name, description)
VALUES ('Default Org', 'Seed org')
ON CONFLICT DO NOTHING;

INSERT INTO milestone.users (password, org_id, email, name, role)
SELECT 'admin123', org_id, 'admin@example.com', 'Admin', 'ADMIN'
FROM milestone.org_master
WHERE org_name='Default Org'
ON CONFLICT DO NOTHING;
