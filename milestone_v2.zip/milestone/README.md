# Milestone Spring Boot

Package: `com.td.milestone`
Controllers:
- `POST /login` — authenticates against `milestone.users` (email or userId + password)
- CRUD for: /orgs, /users, /projects, /tasks, /task-dependencies, /environments, /changes, /milestones, /code-packages
- `POST /projects` accepts tasks inline to create project + tasks.
- Bulk Excel upload endpoints under `/bulk/*` for each table. Upload `.xlsx` with a single header row and the columns in the order shown in `schema.sql` comments.

## Database
Configured for PostgreSQL at `jdbc:postgresql://localhost:5432/postgres?currentSchema=milestone` with user `postgres` / `admin123`.

Spring will run `schema.sql` and `data.sql` on startup.

## Run
```
mvn spring-boot:run
```
Swagger UI at `/swagger`.


Hookup notes (copy/paste)

Save the file as src/App.jsx (for Vite/CRA) or as a Next.js page component and set API_BASE at the top if your backend isn’t on http://localhost:8080.

Make sure your Spring Boot app has CORS enabled for your UI origin, e.g.:

@Bean
public WebMvcConfigurer corsConfigurer() {
return new WebMvcConfigurer() {
@Override public void addCorsMappings(CorsRegistry reg) {
reg.addMapping("/**").allowedOrigins("http://localhost:5173","http://localhost:3000")
.allowedMethods("GET","POST","PUT","DELETE");
}
};
}


CSV flows map to your existing /bulk/ endpoints:

Projects: /bulk/projects

Tasks: /bulk/tasks

Task-Dependencies: /bulk/task-dependencies

Environments: /bulk/environments

Changes: /bulk/changes

Milestones: /bulk/milestones

Code Packages: /bulk/code-packages

What’s “tagging” doing under the hood?

Project ↔ Milestone: milestones don’t have a direct project FK, so the UI “tags” by updating the milestone’s dependentTasks to include tasks from the chosen project (leveraging how your schema relates milestones to tasks).

Task ↔ Code Version: we set ChangeDeployment.task by updating /changes/{id} with the selected taskId. That effectively tags the version_info to that task.

The “project_details.csv” format

The Projects page supports local preview of your custom format:

PROJECT,TASK,ASSIGNED_TO,START,END,DAYS,Comments


It fills a new project form and pre-builds the tasks list so you can review/edit before sending. For actual bulk import to the DB, use the Upload button which posts to /bulk/projects.

If you want this as a full Next.js App Router project scaffold (with Tailwind, shadcn, and a polished layout split across pages), say the word and I’ll generate the full repo with files and package.json.