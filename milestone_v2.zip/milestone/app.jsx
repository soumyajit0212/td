import React, { useEffect, useMemo, useState } from "react";

/**
 * Milestone UI — Single-file React app (green/white theme)
 * Works with the Spring Boot API you generated.
 *
 * How to use:
 * 1) Create a React app (Vite or CRA) and put this file as src/App.jsx (or use Next.js page).
 * 2) Ensure CORS is enabled on the Spring Boot server or run the UI via the same origin.
 * 3) Adjust API_BASE if your backend runs elsewhere.
 * 4) Optional: add Tailwind for nicer visuals; this version uses plain CSS-in-JS for portability.
 */

const API_BASE = "http://localhost:8080";

// ---------------------- Utilities ----------------------
async function api(path, init = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: {
      "Content-Type": init.body instanceof FormData ? undefined : "application/json",
      ...init.headers,
    },
    ...init,
  });
  if (!res.ok) throw new Error(await res.text());
  const ct = res.headers.get("content-type") || "";
  return ct.includes("application/json") ? res.json() : res.text();
}

function Section({ title, children, right }) {
  return (
    <div style={{ background: "#fff", borderRadius: 16, boxShadow: "0 6px 20px rgba(0,0,0,0.06)", marginBottom: 20 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 18px", borderBottom: "1px solid #e8f5e9" }}>
        <h3 style={{ margin: 0, color: "#065f46" }}>{title}</h3>
        <div>{right}</div>
      </div>
      <div style={{ padding: 18 }}>{children}</div>
    </div>
  );
}

function Button({ children, onClick, kind = "solid", disabled, type }) {
  const base = {
    padding: "10px 14px",
    borderRadius: 12,
    border: "1px solid",
    cursor: disabled ? "not-allowed" : "pointer",
    fontWeight: 600,
    marginRight: 8,
  };
  const styles =
    kind === "solid"
      ? { ...base, background: disabled ? "#a7f3d0" : "#059669", color: "white", borderColor: "#059669" }
      : kind === "ghost"
      ? { ...base, background: "transparent", color: "#065f46", borderColor: "#a7f3d0" }
      : { ...base };
  return (
    <button type={type} onClick={disabled ? undefined : onClick} style={styles} disabled={disabled}>
      {children}
    </button>
  );
}

function Input({ label, ...props }) {
  return (
    <label style={{ display: "grid", gridTemplateColumns: "160px 1fr", gap: 10, alignItems: "center", marginBottom: 10 }}>
      <span style={{ color: "#065f46", fontWeight: 600 }}>{label}</span>
      <input {...props} style={{ padding: 10, borderRadius: 10, border: "1px solid #d1fae5" }} />
    </label>
  );
}

function Select({ label, children, ...props }) {
  return (
    <label style={{ display: "grid", gridTemplateColumns: "160px 1fr", gap: 10, alignItems: "center", marginBottom: 10 }}>
      <span style={{ color: "#065f46", fontWeight: 600 }}>{label}</span>
      <select {...props} style={{ padding: 10, borderRadius: 10, border: "1px solid #d1fae5" }}>{children}</select>
    </label>
  );
}

function TextArea({ label, ...props }) {
  return (
    <label style={{ display: "grid", gridTemplateColumns: "160px 1fr", gap: 10, alignItems: "start", marginBottom: 10 }}>
      <span style={{ color: "#065f46", fontWeight: 600, marginTop: 8 }}>{label}</span>
      <textarea {...props} style={{ padding: 10, borderRadius: 10, border: "1px solid #d1fae5", minHeight: 80 }} />
    </label>
  );
}

function Table({ columns, data, rowKey = (r) => r.id, actions }) {
  return (
    <div style={{ overflow: "auto", border: "1px solid #e8f5e9", borderRadius: 12 }}>
      <table style={{ borderCollapse: "separate", borderSpacing: 0, width: "100%" }}>
        <thead style={{ background: "#f0fdf4" }}>
          <tr>
            {columns.map((c) => (
              <th key={c.key || c.title} style={{ textAlign: "left", padding: 10, color: "#065f46", borderBottom: "1px solid #d1fae5" }}>
                {c.title}
              </th>
            ))}
            {actions && <th style={{ padding: 10 }} />}
          </tr>
        </thead>
        <tbody>
          {data.map((row, idx) => (
            <tr key={rowKey(row) || idx} style={{ background: idx % 2 === 0 ? "#fff" : "#fbfff9" }}>
              {columns.map((c) => (
                <td key={c.key || c.title} style={{ padding: 10, borderBottom: "1px solid #f0fdf4" }}>
                  {c.render ? c.render(row) : row[c.dataIndex]}
                </td>
              ))}
              {actions && (
                <td style={{ padding: 10, borderBottom: "1px solid #f0fdf4", whiteSpace: "nowrap" }}>{actions(row)}</td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function FileUpload({ label, onFile, accept = ".csv,.xlsx" }) {
  const [fileName, setFileName] = useState("");
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "8px 0" }}>
      <label style={{ color: "#065f46", fontWeight: 600 }}>{label}</label>
      <input
        type="file"
        accept={accept}
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) {
            setFileName(f.name);
            onFile?.(f);
          }
        }}
      />
      <span style={{ color: "#047857" }}>{fileName}</span>
    </div>
  );
}

function Logo() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      {/* Placeholder logo box */}
      <div style={{ width: 36, height: 36, background: "#059669", borderRadius: 8 }} />
      <div style={{ fontWeight: 800, color: "#065f46" }}>Milestone Suite</div>
    </div>
  );
}

// ---------------------- Auth ----------------------
function Login({ onLogin }) {
  const [usernameOrEmail, setU] = useState("");
  const [password, setP] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function doLogin(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await api("/login", {
        method: "POST",
        body: JSON.stringify({ usernameOrEmail, password }),
      });
      if (!res.success) throw new Error(res.message || "Login failed");
      onLogin({ userId: res.userId, role: res.role || "USER" });
    } catch (err) {
      setError(String(err.message || err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ height: "100vh", display: "grid", placeItems: "center", background: "linear-gradient(135deg,#ecfdf5 0%, #ffffff 60%)" }}>
      <form onSubmit={doLogin} style={{ background: "#fff", padding: 28, borderRadius: 16, width: 380, boxShadow: "0 10px 30px rgba(0,0,0,0.08)", border: "1px solid #d1fae5" }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 18 }}>
          <Logo />
        </div>
        <h2 style={{ marginTop: 0, color: "#065f46" }}>Sign in</h2>
        {error && <div style={{ background: "#fef2f2", color: "#991b1b", padding: 10, borderRadius: 10, marginBottom: 10 }}>{error}</div>}
        <Input label="Email/User ID" value={usernameOrEmail} onChange={(e) => setU(e.target.value)} />
        <Input label="Password" type="password" value={password} onChange={(e) => setP(e.target.value)} />
        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 10 }}>
          <Button type="submit" disabled={loading}>{loading ? "Signing in..." : "Sign in"}</Button>
        </div>
      </form>
    </div>
  );
}

// ---------------------- Layout ----------------------
const NAV = [
  { key: "dashboard", label: "Dashboard" },
  { key: "projects", label: "Project Management" },
  { key: "code", label: "Code Packages" },
  { key: "env", label: "Environment Mgmt" },
  { key: "milestone", label: "Milestone Mgmt" },
  { key: "change", label: "Change Mgmt" },
  { key: "users", label: "User Mgmt (Admin)" },
  { key: "uploads", label: "Upload Files" },
];

function Shell({ user, onLogout, active, setActive, children }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", minHeight: "100vh", background: "#f6fffb" }}>
      <aside style={{ padding: 16, borderRight: "1px solid #e6f7f1", background: "#ffffff" }}>
        <div style={{ marginBottom: 16 }}><Logo /></div>
        {NAV.map((n) => {
          const disabled = n.key === "users" && user.role !== "ADMIN";
          const isActive = active === n.key;
          return (
            <div
              key={n.key}
              onClick={() => !disabled && setActive(n.key)}
              style={{
                padding: "10px 12px",
                marginBottom: 8,
                borderRadius: 10,
                cursor: disabled ? "not-allowed" : "pointer",
                color: disabled ? "#9ca3af" : isActive ? "#065f46" : "#047857",
                background: isActive ? "#ecfdf5" : "transparent",
                border: isActive ? "1px solid #a7f3d0" : "1px solid transparent",
                fontWeight: 600,
              }}
            >
              {n.label}
            </div>
          );
        })}
        <div style={{ position: "absolute", bottom: 18 }}>
          <div style={{ color: "#065f46", fontWeight: 700 }}>Hello, {user.role || "User"}</div>
          <Button kind="ghost" onClick={onLogout}>Logout</Button>
        </div>
      </aside>
      <main style={{ padding: 22 }}>
        {children}
      </main>
    </div>
  );
}

// ---------------------- Data hooks ----------------------
function useFetchList(path, deps = []) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const reload = async () => {
    try {
      setLoading(true); setError("");
      const d = await api(path);
      setData(Array.isArray(d) ? d : []);
    } catch (e) { setError(String(e.message || e)); } finally { setLoading(false); }
  };
  useEffect(() => { reload(); }, deps); // eslint-disable-line
  return { data, setData, loading, error, reload };
}

// ---------------------- Project Management ----------------------
function ProjectsPage({ users, changes, milestones, tasksRefreshSignal, setTasksRefreshSignal }) {
  const { data: projects, reload: reloadProjects } = useFetchList("/projects", []);
  const { data: tasks, reload: reloadTasks } = useFetchList("/tasks", []);

  // Create project + tasks
  const [form, setForm] = useState({ orgId: 1, projectName: "", description: "", startDate: "", endDate: "", status: "PLANNED" });
  const [taskDrafts, setTaskDrafts] = useState([]);
  const [uploadFile, setUploadFile] = useState(null);

  function addTaskDraft() {
    setTaskDrafts((a) => [...a, { taskName: "", description: "", startDate: "", endDate: "", taskType: "", assignedToUserId: "", jiraRef: "", comments: "" }]);
  }

  function removeTaskDraft(i) {
    setTaskDrafts((a) => a.filter((_, idx) => idx !== i));
  }

  async function createProject() {
    const payload = {
      ...form,
      tasks: taskDrafts.map((t) => ({
        ...t,
        assignedToUserId: t.assignedToUserId ? Number(t.assignedToUserId) : null,
        startDate: t.startDate || null,
        endDate: t.endDate || null,
      })),
    };
    await api("/projects", { method: "POST", body: JSON.stringify(payload) });
    setForm({ orgId: 1, projectName: "", description: "", startDate: "", endDate: "", status: "PLANNED" });
    setTaskDrafts([]);
    await reloadProjects();
    await reloadTasks();
  }

  async function delProject(p) {
    await api(`/projects/${p.projectId}`, { method: "DELETE" });
    await reloadProjects();
    await reloadTasks();
  }

  // CSV upload to /bulk/projects or using the custom format project_details.csv
  async function uploadCSVToProjects() {
    if (!uploadFile) return;
    const fd = new FormData();
    fd.append("file", uploadFile);
    await api("/bulk/projects", { method: "POST", body: fd });
    await reloadProjects();
    await reloadTasks();
  }

  // Parse project_details.csv locally (PROJECT,TASK,ASSIGNED_TO,START,END,DAYS,Comments)
  async function parseProjectDetailsCSV(file) {
    const text = await file.text();
    const lines = text.split(/\r?\n/).filter(Boolean);
    const header = lines.shift();
    const idx = (name) => header.split(",").map((h) => h.trim().toUpperCase()).indexOf(name);
    const iProj = idx("PROJECT"), iTask = idx("TASK"), iAssign = idx("ASSIGNED_TO"), iStart = idx("START"), iEnd = idx("END"), iComments = idx("COMMENTS");
    const map = new Map();
    for (const line of lines) {
      const cols = line.split(",");
      const proj = cols[iProj]?.trim() || "Untitled";
      const task = cols[iTask]?.trim();
      const assigned = cols[iAssign]?.trim();
      const start = cols[iStart]?.trim();
      const end = cols[iEnd]?.trim();
      const comments = cols[iComments]?.trim();
      if (!map.has(proj)) map.set(proj, []);
      if (task) map.get(proj).push({ taskName: task, assignedToUserId: assigned || "", startDate: start || "", endDate: end || "", comments: comments || "" });
    }
    // Preview: populate drafts for first project name
    const [firstProj] = map.keys();
    if (firstProj) {
      setForm((f) => ({ ...f, projectName: firstProj }));
      setTaskDrafts(map.get(firstProj));
    }
  }

  // Tag milestone to project by adding selected tasks to milestone.dependentTasks
  async function tagMilestoneToProject(projectId, milestoneId, taskIds) {
    const ms = milestones.find((m) => m.milId === milestoneId);
    if (!ms) return;
    const updated = { ...ms, dependentTasks: [...new Set([...(ms.dependentTasks || []), ...taskIds])] };
    await api(`/milestones/${milestoneId}`, { method: "PUT", body: JSON.stringify(updated) });
    alert("Milestone tagged to project via dependent tasks.");
  }

  // Tag code_version to a task by setting ChangeDeployment.task
  async function tagCodeVersionToTask(changeId, taskId) {
    const ch = changes.find((c) => c.changeId === changeId);
    if (!ch) return;
    const updated = { ...ch, task: { taskId } };
    await api(`/changes/${changeId}`, { method: "PUT", body: JSON.stringify(updated) });
    setTasksRefreshSignal((x) => x + 1);
    alert("Change version tagged to task.");
  }

  return (
    <div>
      <Section title="Create New Project">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
          <div>
            <Input label="Org ID" type="number" value={form.orgId} onChange={(e) => setForm({ ...form, orgId: Number(e.target.value) })} />
            <Input label="Project Name" value={form.projectName} onChange={(e) => setForm({ ...form, projectName: e.target.value })} />
            <TextArea label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            <Input label="Start Date" type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
            <Input label="End Date" type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
            <Input label="Status" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} />
            <div style={{ marginTop: 8 }}>
              <Button onClick={createProject}>Create project</Button>
              <Button kind="ghost" onClick={() => { setForm({ orgId: 1, projectName: "", description: "", startDate: "", endDate: "", status: "PLANNED" }); setTaskDrafts([]); }}>Reset</Button>
            </div>
          </div>

          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <h4 style={{ color: "#065f46", margin: 0 }}>Tasks for this project</h4>
              <div>
                <Button kind="ghost" onClick={addTaskDraft}>+ Add Task</Button>
              </div>
            </div>
            {taskDrafts.map((t, i) => (
              <div key={i} style={{ border: "1px solid #d1fae5", borderRadius: 12, padding: 12, marginTop: 10 }}>
                <Input label="Task Name" value={t.taskName} onChange={(e) => setTaskDrafts((arr) => arr.map((x, idx) => (idx === i ? { ...x, taskName: e.target.value } : x)))} />
                <TextArea label="Description" value={t.description} onChange={(e) => setTaskDrafts((arr) => arr.map((x, idx) => (idx === i ? { ...x, description: e.target.value } : x)))} />
                <Input label="Start Date" type="date" value={t.startDate} onChange={(e) => setTaskDrafts((arr) => arr.map((x, idx) => (idx === i ? { ...x, startDate: e.target.value } : x)))} />
                <Input label="End Date" type="date" value={t.endDate} onChange={(e) => setTaskDrafts((arr) => arr.map((x, idx) => (idx === i ? { ...x, endDate: e.target.value } : x)))} />
                <Input label="Task Type" value={t.taskType} onChange={(e) => setTaskDrafts((arr) => arr.map((x, idx) => (idx === i ? { ...x, taskType: e.target.value } : x)))} />
                <Select label="Assigned To (User)" value={t.assignedToUserId} onChange={(e) => setTaskDrafts((arr) => arr.map((x, idx) => (idx === i ? { ...x, assignedToUserId: e.target.value } : x)))}>
                  <option value="">Unassigned</option>
                  {users.map((u) => (
                    <option key={u.userId} value={u.userId}>{u.name || u.email} (#{u.userId})</option>
                  ))}
                </Select>
                <Input label="Jira Ref" value={t.jiraRef || ""} onChange={(e) => setTaskDrafts((arr) => arr.map((x, idx) => (idx === i ? { ...x, jiraRef: e.target.value } : x)))} />
                <TextArea label="Comments" value={t.comments || ""} onChange={(e) => setTaskDrafts((arr) => arr.map((x, idx) => (idx === i ? { ...x, comments: e.target.value } : x)))} />
                <div style={{ display: "flex", justifyContent: "flex-end" }}>
                  <Button kind="ghost" onClick={() => removeTaskDraft(i)}>Remove</Button>
                </div>
              </div>
            ))}

            <Section title="Project CSV (project_details.csv)" right={null}>
              <FileUpload label="Load CSV locally" onFile={parseProjectDetailsCSV} accept={".csv"} />
              <FileUpload label="Upload to backend /bulk/projects" onFile={setUploadFile} accept={".csv,.xlsx"} />
              <Button onClick={uploadCSVToProjects} disabled={!uploadFile}>Upload</Button>
            </Section>
          </div>
        </div>
      </Section>

      <Section title="Existing Projects & Tasks" right={<Button kind="ghost" onClick={() => { reloadProjects(); reloadTasks(); }}>Refresh</Button>}>
        <Table
          columns={[
            { title: "ID", dataIndex: "projectId" },
            { title: "Project", dataIndex: "projectName" },
            { title: "Status", dataIndex: "status" },
            { title: "Start", render: (r) => r.startDate || "" },
            { title: "End", render: (r) => r.endDate || "" },
            { title: "Tasks", render: (r) => tasks.filter((t) => t.project?.projectId === r.projectId).length },
          ]}
          data={projects}
          rowKey={(r) => r.projectId}
          actions={(p) => (
            <div>
              <Button kind="ghost" onClick={() => delProject(p)}>Delete</Button>
            </div>
          )}
        />

        <div style={{ marginTop: 16, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
          <Section title="Tag Milestone to Project (via tasks)">
            <ProjectMilestoneTagger projects={projects} milestones={milestones} tasks={tasks} onTag={tagMilestoneToProject} />
          </Section>
          <Section title="Tag Change Version to Task">
            <TaskChangeTagger changes={changes} tasks={tasks} onTag={tagCodeVersionToTask} />
          </Section>
        </div>
      </Section>
    </div>
  );
}

function ProjectMilestoneTagger({ projects, milestones, tasks, onTag }) {
  const [projectId, setProjectId] = useState("");
  const [milestoneId, setMilestoneId] = useState("");
  const [selectedTaskIds, setSelectedTaskIds] = useState([]);

  const projectTasks = useMemo(() => tasks.filter((t) => t.project?.projectId === Number(projectId)), [tasks, projectId]);

  function toggleTask(id) {
    setSelectedTaskIds((arr) => (arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id]));
  }

  return (
    <div>
      <Select label="Project" value={projectId} onChange={(e) => setProjectId(e.target.value)}>
        <option value="">Select project</option>
        {projects.map((p) => (
          <option key={p.projectId} value={p.projectId}>{p.projectName}</option>
        ))}
      </Select>
      <Select label="Milestone" value={milestoneId} onChange={(e) => setMilestoneId(e.target.value)}>
        <option value="">Select milestone</option>
        {milestones.map((m) => (
          <option key={m.milId} value={m.milId}>{m.milestoneName} (#{m.milId})</option>
        ))}
      </Select>

      <div style={{ marginTop: 10, border: "1px solid #d1fae5", borderRadius: 12, padding: 10 }}>
        <div style={{ fontWeight: 700, color: "#065f46", marginBottom: 8 }}>Select tasks</div>
        {projectTasks.length === 0 && <div style={{ color: "#064e3b" }}>No tasks for this project.</div>}
        {projectTasks.map((t) => (
          <label key={t.taskId} style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <input type="checkbox" checked={selectedTaskIds.includes(t.taskId)} onChange={() => toggleTask(t.taskId)} />
            <span>{t.taskName} (#{t.taskId})</span>
          </label>
        ))}
      </div>
      <div style={{ marginTop: 10 }}>
        <Button onClick={() => onTag(Number(projectId), Number(milestoneId), selectedTaskIds)} disabled={!projectId || !milestoneId || selectedTaskIds.length === 0}>
          Tag Milestone
        </Button>
      </div>
    </div>
  );
}

function TaskChangeTagger({ changes, tasks, onTag }) {
  const [taskId, setTaskId] = useState("");
  const [changeId, setChangeId] = useState("");

  return (
    <div>
      <Select label="Task" value={taskId} onChange={(e) => setTaskId(e.target.value)}>
        <option value="">Select task</option>
        {tasks.map((t) => (
          <option key={t.taskId} value={t.taskId}>{t.taskName} (#{t.taskId})</option>
        ))}
      </Select>
      <Select label="Change (code version)" value={changeId} onChange={(e) => setChangeId(e.target.value)}>
        <option value="">Select change</option>
        {changes.map((c) => (
          <option key={c.changeId} value={c.changeId}>{c.versionInfo} (#{c.changeId})</option>
        ))}
      </Select>
      <Button onClick={() => onTag(Number(changeId), Number(taskId))} disabled={!taskId || !changeId}>Tag Version to Task</Button>
    </div>
  );
}

// ---------------------- Code Packages ----------------------
function CodePackagesPage({ environments, changes }) {
  const { data: pkgs, reload } = useFetchList("/code-packages", []);
  const [draft, setDraft] = useState({ manifestFile: "", objectName: "", objectType: "", deployedEnv: "", changeVersion: "" });
  const [file, setFile] = useState(null);

  function asEntity(d) {
    const envObj = environments.find((e) => e.envId === Number(d.deployedEnv));
    const chObj = changes.find((c) => c.versionInfo === d.changeVersion);
    return {
      codeId: d.codeId,
      manifestFile: d.manifestFile || null,
      objectName: d.objectName || null,
      objectType: d.objectType || null,
      deployedEnv: envObj ? { envId: envObj.envId } : null,
      changeDeployment: chObj ? { changeId: chObj.changeId } : null,
    };
  }

  async function save() {
    const entity = asEntity(draft);
    await api("/code-packages", { method: "POST", body: JSON.stringify(entity) });
    setDraft({ manifestFile: "", objectName: "", objectType: "", deployedEnv: "", changeVersion: "" });
    await reload();
  }

  async function del(row) {
    await api(`/code-packages/${row.codeId}`, { method: "DELETE" });
    await reload();
  }

  // Bulk upload via backend
  async function uploadBulk() {
    if (!file) return;
    const fd = new FormData(); fd.append("file", file);
    await api("/bulk/code-packages", { method: "POST", body: fd });
    await reload();
  }

  // Duplicates by (object_name, object_type)
  const duplicates = useMemo(() => {
    const map = new Map();
    for (const p of pkgs) {
      const key = `${p.objectName || ""}|${p.objectType || ""}`;
      map.set(key, (map.get(key) || 0) + 1);
    }
    return [...map.entries()].filter(([k, v]) => v > 1).map(([k, v]) => ({ key: k, count: v }));
  }, [pkgs]);

  return (
    <div>
      <Section title="Add Code Package">
        <Input label="Manifest File" value={draft.manifestFile} onChange={(e) => setDraft({ ...draft, manifestFile: e.target.value })} />
        <Input label="Object Name" value={draft.objectName} onChange={(e) => setDraft({ ...draft, objectName: e.target.value })} />
        <Input label="Object Type" value={draft.objectType} onChange={(e) => setDraft({ ...draft, objectType: e.target.value })} />
        <Select label="Deployed Env" value={draft.deployedEnv} onChange={(e) => setDraft({ ...draft, deployedEnv: e.target.value })}>
          <option value="">Select env</option>
          {environments.map((e) => (
            <option key={e.envId} value={e.envId}>{e.envName} (#{e.envId})</option>
          ))}
        </Select>
        <Select label="Code Version (Change)" value={draft.changeVersion} onChange={(e) => setDraft({ ...draft, changeVersion: e.target.value })}>
          <option value="">Select version</option>
          {changes.map((c) => (
            <option key={c.changeId} value={c.versionInfo}>{c.versionInfo}</option>
          ))}
        </Select>
        <Button onClick={save}>Save</Button>
      </Section>

      <Section title="Bulk Upload (CSV/XLSX)">
        <FileUpload label="File" onFile={setFile} />
        <Button onClick={uploadBulk} disabled={!file}>Upload</Button>
      </Section>

      <Section title="Packages List">
        <Table
          columns={[
            { title: "ID", dataIndex: "codeId" },
            { title: "Object", render: (r) => `${r.objectName || ""}` },
            { title: "Type", dataIndex: "objectType" },
            { title: "Version", render: (r) => r.changeDeployment?.versionInfo || "" },
            { title: "Manifest", dataIndex: "manifestFile" },
          ]}
          data={pkgs}
          rowKey={(r) => r.codeId}
          actions={(row) => <Button kind="ghost" onClick={() => del(row)}>Delete</Button>}
        />
      </Section>

      <Section title="Duplicates by (object_name, object_type)">
        <Table
          columns={[{ title: "Key", dataIndex: "key" }, { title: "Count", dataIndex: "count" }]}
          data={duplicates}
          rowKey={(r) => r.key}
        />
      </Section>
    </div>
  );
}

// ---------------------- Environment Management ----------------------
function EnvironmentsPage() {
  const { data: envs, reload } = useFetchList("/environments", []);
  const [d, setD] = useState({ orgId: 1, envName: "", envType: "", username: "", hostname: "", databaseUrl: "", schemaName: "", password: "" });
  const [file, setFile] = useState(null);

  async function save() {
    const entity = { ...d, org: { orgId: Number(d.orgId || 1) } };
    await api("/environments", { method: "POST", body: JSON.stringify(entity) });
    setD({ orgId: 1, envName: "", envType: "", username: "", hostname: "", databaseUrl: "", schemaName: "", password: "" });
    await reload();
  }

  async function del(row) { await api(`/environments/${row.envId}`, { method: "DELETE" }); await reload(); }

  async function upload() {
    if (!file) return; const fd = new FormData(); fd.append("file", file);
    await api("/bulk/environments", { method: "POST", body: fd });
    await reload();
  }

  return (
    <div>
      <Section title="Add Environment">
        <Input label="Org ID" type="number" value={d.orgId} onChange={(e) => setD({ ...d, orgId: e.target.value })} />
        <Input label="Name" value={d.envName} onChange={(e) => setD({ ...d, envName: e.target.value })} />
        <Input label="Type" value={d.envType} onChange={(e) => setD({ ...d, envType: e.target.value })} />
        <Input label="Username" value={d.username} onChange={(e) => setD({ ...d, username: e.target.value })} />
        <Input label="Hostname" value={d.hostname} onChange={(e) => setD({ ...d, hostname: e.target.value })} />
        <Input label="DB URL" value={d.databaseUrl} onChange={(e) => setD({ ...d, databaseUrl: e.target.value })} />
        <Input label="Schema" value={d.schemaName} onChange={(e) => setD({ ...d, schemaName: e.target.value })} />
        <Input label="Password" type="password" value={d.password} onChange={(e) => setD({ ...d, password: e.target.value })} />
        <Button onClick={save}>Save</Button>
      </Section>

      <Section title="Bulk Upload">
        <FileUpload label="environments.csv/.xlsx" onFile={setFile} />
        <Button onClick={upload} disabled={!file}>Upload</Button>
      </Section>

      <Section title="Environments">
        <Table
          columns={[
            { title: "ID", dataIndex: "envId" },
            { title: "Name", dataIndex: "envName" },
            { title: "Type", dataIndex: "envType" },
            { title: "Host", dataIndex: "hostname" },
            { title: "User", dataIndex: "username" },
          ]}
          data={envs}
          rowKey={(r) => r.envId}
          actions={(r) => <Button kind="ghost" onClick={() => del(r)}>Delete</Button>}
        />
      </Section>
    </div>
  );
}

// ---------------------- Milestone Management ----------------------
function MilestonesPage() {
  const { data: milestones, reload } = useFetchList("/milestones", []);
  const [d, setD] = useState({ orgId: 1, milestoneName: "", targetDate: "", comments: "" });
  const [file, setFile] = useState(null);

  async function save() {
    const entity = { ...d, org: { orgId: Number(d.orgId || 1) }, isLatest: "Y" };
    await api("/milestones", { method: "POST", body: JSON.stringify(entity) });
    setD({ orgId: 1, milestoneName: "", targetDate: "", comments: "" });
    await reload();
  }

  async function del(row) { await api(`/milestones/${row.milId}`, { method: "DELETE" }); await reload(); }

  async function bumpVersion(row) {
    const next = (() => {
      const v = row.versionInfo || "v0";
      const m = /v(\d+)/i.exec(v); const n = m ? Number(m[1]) + 1 : 1; return `v${n}`;
    })();
    const updated = { ...row, versionInfo: next };
    await api(`/milestones/${row.milId}`, { method: "PUT", body: JSON.stringify(updated) });
    await reload();
  }

  async function upload() {
    if (!file) return; const fd = new FormData(); fd.append("file", file);
    await api("/bulk/milestones", { method: "POST", body: fd });
    await reload();
  }

  return (
    <div>
      <Section title="Add Milestone">
        <Input label="Org ID" type="number" value={d.orgId} onChange={(e) => setD({ ...d, orgId: e.target.value })} />
        <Input label="Milestone Name" value={d.milestoneName} onChange={(e) => setD({ ...d, milestoneName: e.target.value })} />
        <Input label="Target Date" type="date" value={d.targetDate} onChange={(e) => setD({ ...d, targetDate: e.target.value })} />
        <TextArea label="Comments" value={d.comments} onChange={(e) => setD({ ...d, comments: e.target.value })} />
        <Button onClick={save}>Save</Button>
      </Section>

      <Section title="Bulk Upload">
        <FileUpload label="milestones.csv/.xlsx" onFile={setFile} />
        <Button onClick={upload} disabled={!file}>Upload</Button>
      </Section>

      <Section title="Milestones">
        <Table
          columns={[
            { title: "ID", dataIndex: "milId" },
            { title: "Name", dataIndex: "milestoneName" },
            { title: "Target", dataIndex: "targetDate" },
            { title: "Version", dataIndex: "versionInfo" },
            { title: "Latest?", dataIndex: "isLatest" },
          ]}
          data={milestones}
          rowKey={(r) => r.milId}
          actions={(r) => (
            <>
              <Button kind="ghost" onClick={() => bumpVersion(r)}>+ Version</Button>
              <Button kind="ghost" onClick={() => del(r)}>Delete</Button>
            </>
          )}
        />
      </Section>
    </div>
  );
}

// ---------------------- Change Management ----------------------
function ChangesPage({ environments, tasks }) {
  const { data: changes, reload } = useFetchList("/changes", []);
  const [d, setD] = useState({ changeType: "patch", envId: "", plannedDeployDate: "", actualDeployDate: "", versionInfo: "", manifestFile: "", jiraRef: "", changeRef: "", taskId: "" });
  const [file, setFile] = useState(null);

  async function save() {
    const env = environments.find((e) => e.envId === Number(d.envId));
    const task = tasks.find((t) => t.taskId === Number(d.taskId));
    const entity = {
      changeType: d.changeType,
      environment: env ? { envId: env.envId } : null,
      plannedDeployDate: d.plannedDeployDate || null,
      actualDeployDate: d.actualDeployDate || null,
      versionInfo: d.versionInfo || null,
      manifestFile: d.manifestFile || null,
      jiraRef: d.jiraRef || null,
      changeRef: d.changeRef || null,
      task: task ? { taskId: task.taskId } : null,
    };
    await api("/changes", { method: "POST", body: JSON.stringify(entity) });
    setD({ changeType: "patch", envId: "", plannedDeployDate: "", actualDeployDate: "", versionInfo: "", manifestFile: "", jiraRef: "", changeRef: "", taskId: "" });
    await reload();
  }

  async function del(row) { await api(`/changes/${row.changeId}`, { method: "DELETE" }); await reload(); }
  async function upload() { if (!file) return; const fd = new FormData(); fd.append("file", file); await api("/bulk/changes", { method: "POST", body: fd }); await reload(); }

  return (
    <div>
      <Section title="Add Change">
        <Select label="Type" value={d.changeType} onChange={(e) => setD({ ...d, changeType: e.target.value })}>
          <option value="patch">patch</option>
          <option value="code drop">code drop</option>
          <option value="DM change">DM change</option>
        </Select>
        <Select label="Environment" value={d.envId} onChange={(e) => setD({ ...d, envId: e.target.value })}>
          <option value="">Select env</option>
          {environments.map((e) => (
            <option key={e.envId} value={e.envId}>{e.envName}</option>
          ))}
        </Select>
        <Input label="Planned Deploy" type="date" value={d.plannedDeployDate} onChange={(e) => setD({ ...d, plannedDeployDate: e.target.value })} />
        <Input label="Actual Deploy" type="date" value={d.actualDeployDate} onChange={(e) => setD({ ...d, actualDeployDate: e.target.value })} />
        <Input label="Version Info" value={d.versionInfo} onChange={(e) => setD({ ...d, versionInfo: e.target.value })} />
        <Input label="Manifest File" value={d.manifestFile} onChange={(e) => setD({ ...d, manifestFile: e.target.value })} />
        <Input label="Jira Ref" value={d.jiraRef} onChange={(e) => setD({ ...d, jiraRef: e.target.value })} />
        <Input label="Change Ref" value={d.changeRef} onChange={(e) => setD({ ...d, changeRef: e.target.value })} />
        <Select label="Tag to Task" value={d.taskId} onChange={(e) => setD({ ...d, taskId: e.target.value })}>
          <option value="">None</option>
          {tasks.map((t) => (
            <option key={t.taskId} value={t.taskId}>{t.taskName} (#{t.taskId})</option>
          ))}
        </Select>
        <Button onClick={save}>Save</Button>
      </Section>

      <Section title="Bulk Upload">
        <FileUpload label="changes.csv/.xlsx" onFile={setFile} />
        <Button onClick={upload} disabled={!file}>Upload</Button>
      </Section>

      <Section title="Changes">
        <Table
          columns={[
            { title: "ID", dataIndex: "changeId" },
            { title: "Type", dataIndex: "changeType" },
            { title: "Env", render: (r) => r.environment?.envName || r.environment?.envId || "" },
            { title: "Version", dataIndex: "versionInfo" },
            { title: "Planned", dataIndex: "plannedDeployDate" },
            { title: "Task", render: (r) => r.task?.taskName || r.task?.taskId || "" },
          ]}
          data={changes}
          rowKey={(r) => r.changeId}
          actions={(r) => <Button kind="ghost" onClick={() => del(r)}>Delete</Button>}
        />
      </Section>
    </div>
  );
}

// ---------------------- User Management (Admin) ----------------------
function UsersPage() {
  const { data: users, reload } = useFetchList("/users", []);
  const [d, setD] = useState({ email: "", password: "", name: "", role: "USER", orgId: 1 });

  async function save() {
    const entity = { email: d.email, password: d.password, name: d.name, role: d.role, org: { orgId: Number(d.orgId || 1) } };
    await api("/users", { method: "POST", body: JSON.stringify(entity) });
    setD({ email: "", password: "", name: "", role: "USER", orgId: 1 });
    await reload();
  }

  async function del(row) { await api(`/users/${row.userId}`, { method: "DELETE" }); await reload(); }

  return (
    <div>
      <Section title="Add User">
        <Input label="Email" value={d.email} onChange={(e) => setD({ ...d, email: e.target.value })} />
        <Input label="Password" type="password" value={d.password} onChange={(e) => setD({ ...d, password: e.target.value })} />
        <Input label="Name" value={d.name} onChange={(e) => setD({ ...d, name: e.target.value })} />
        <Select label="Role" value={d.role} onChange={(e) => setD({ ...d, role: e.target.value })}>
          <option value="USER">USER</option>
          <option value="ADMIN">ADMIN</option>
        </Select>
        <Input label="Org ID" type="number" value={d.orgId} onChange={(e) => setD({ ...d, orgId: e.target.value })} />
        <Button onClick={save}>Save</Button>
      </Section>

      <Section title="Users">
        <Table
          columns={[
            { title: "ID", dataIndex: "userId" },
            { title: "Email", dataIndex: "email" },
            { title: "Name", dataIndex: "name" },
            { title: "Role", dataIndex: "role" },
          ]}
          data={users}
          rowKey={(r) => r.userId}
          actions={(r) => <Button kind="ghost" onClick={() => del(r)}>Delete</Button>}
        />
      </Section>
    </div>
  );
}

// ---------------------- Uploads Page ----------------------
function UploadsPage() {
  const [target, setTarget] = useState("projects");
  const [file, setFile] = useState(null);
  async function upload() {
    if (!file) return;
    const fd = new FormData(); fd.append("file", file);
    await api(`/bulk/${target}`, { method: "POST", body: fd });
    alert("Uploaded to backend and processed.");
  }
  return (
    <Section title="Upload CSV/XLSX to Backend">
      <Select label="Target" value={target} onChange={(e) => setTarget(e.target.value)}>
        <option value="projects">Projects</option>
        <option value="tasks">Tasks</option>
        <option value="task-dependencies">Task Dependencies</option>
        <option value="environments">Environments</option>
        <option value="changes">Changes</option>
        <option value="milestones">Milestones</option>
        <option value="code-packages">Code Packages</option>
      </Select>
      <FileUpload label="Pick file (.csv/.xlsx)" onFile={setFile} />
      <Button onClick={upload} disabled={!file}>Upload</Button>
    </Section>
  );
}

// ---------------------- Dashboard ----------------------
function DashboardPage() {
  const { data: changes } = useFetchList("/changes", []);
  const { data: envs } = useFetchList("/environments", []);
  const { data: projects } = useFetchList("/projects", []);
  const { data: tasks } = useFetchList("/tasks", []);
  const { data: milestones } = useFetchList("/milestones", []);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const range = (d) => {
    if (!from && !to) return true;
    const iso = (x) => (x ? new Date(x).getTime() : 0);
    const t = iso(d);
    return (!from || t >= iso(from)) && (!to || t <= iso(to));
  };

  const envDeploys = useMemo(() => {
    const map = new Map();
    for (const c of changes) {
      if (!range(c.plannedDeployDate)) continue;
      const key = c.environment?.envName || `env-${c.environment?.envId || "NA"}`;
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(c);
    }
    for (const [k, arr] of map) arr.sort((a, b) => String(a.versionInfo || "").localeCompare(String(b.versionInfo || "")));
    return [...map.entries()].map(([env, arr]) => ({ env, count: arr.length, items: arr }));
  }, [changes, from, to]);

  const now = Date.now();
  const next7 = now + 7 * 24 * 3600 * 1000;

  const upcomingDeployments = useMemo(() => changes.filter((c) => c.task && new Date(c.task?.endDate || c.plannedDeployDate || 0).getTime() <= next7 && new Date(c.task?.endDate || 0).getTime() >= now), [changes]);
  const upcomingTasks = useMemo(() => tasks.filter((t) => { const d = new Date(t.endDate || 0).getTime(); return d >= now && d <= next7; }), [tasks]);
  const ongoingProjects = useMemo(() => projects.filter((p) => !["COMPLETED", "CLOSED"].includes(String(p.status || "").toUpperCase())), [projects]);
  const msThisWeek = useMemo(() => milestones.filter((m) => { const d = new Date(m.targetDate || 0).getTime(); return d >= now && d <= next7; }), [milestones]);
  const msCompletedThisWeek = useMemo(() => milestones.filter((m) => String(m.isLatest || "").toUpperCase() === "Y" && new Date(m.targetDate || 0).getTime() <= now && new Date(m.targetDate || 0).getTime() >= now - 7 * 24 * 3600 * 1000), [milestones]);
  const delayedProjects = useMemo(() => projects.filter((p) => new Date(p.endDate || 0).getTime() < now && !["COMPLETED", "CLOSED"].includes(String(p.status || "").toUpperCase())), [projects]);
  const delayedTasks = useMemo(() => tasks.filter((t) => new Date(t.endDate || 0).getTime() < now), [tasks]);

  return (
    <div>
      <Section title="Filters">
        <div style={{ display: "flex", gap: 12 }}>
          <Input label="From" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          <Input label="To" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
      </Section>

      <Section title="Deployments by Environment (ordered by version)">
        {envDeploys.map((g) => (
          <div key={g.env} style={{ marginBottom: 12 }}>
            <div style={{ fontWeight: 700, color: "#065f46" }}>{g.env} — {g.count}</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 6 }}>
              {g.items.map((c) => (
                <span key={c.changeId} style={{ border: "1px solid #a7f3d0", color: "#065f46", padding: "6px 10px", borderRadius: 999 }}>{c.versionInfo || "(no ver)"}</span>
              ))}
            </div>
          </div>
        ))}
      </Section>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
        <Section title="Upcoming Deployments (next 7 days)">
          <Table columns={[{ title: "Version", dataIndex: "versionInfo" }, { title: "Env", render: (r) => r.environment?.envName || "" }, { title: "Task End", render: (r) => r.task?.endDate || "" }]} data={upcomingDeployments} rowKey={(r) => r.changeId} />
        </Section>
        <Section title="Upcoming Tasks (next 7 days)">
          <Table columns={[{ title: "Task", dataIndex: "taskName" }, { title: "Project", render: (r) => r.project?.projectName || "" }, { title: "End", dataIndex: "endDate" }]} data={upcomingTasks} rowKey={(r) => r.taskId} />
        </Section>
        <Section title="Ongoing Projects">
          <Table columns={[{ title: "Project", dataIndex: "projectName" }, { title: "Status", dataIndex: "status" }]} data={ongoingProjects} rowKey={(r) => r.projectId} />
        </Section>
        <Section title="Milestones — due this week">
          <Table columns={[{ title: "Milestone", dataIndex: "milestoneName" }, { title: "Target", dataIndex: "targetDate" }]} data={msThisWeek} rowKey={(r) => r.milId} />
        </Section>
        <Section title="Milestones — completed this week (is_latest=Y)">
          <Table columns={[{ title: "Milestone", dataIndex: "milestoneName" }, { title: "Target", dataIndex: "targetDate" }, { title: "Version", dataIndex: "versionInfo" }]} data={msCompletedThisWeek} rowKey={(r) => r.milId} />
        </Section>
        <Section title="Delayed Projects">
          <Table columns={[{ title: "Project", dataIndex: "projectName" }, { title: "End", dataIndex: "endDate" }, { title: "Status", dataIndex: "status" }]} data={delayedProjects} rowKey={(r) => r.projectId} />
        </Section>
        <Section title="Delayed Tasks">
          <Table columns={[{ title: "Task", dataIndex: "taskName" }, { title: "End", dataIndex: "endDate" }, { title: "Project", render: (r) => r.project?.projectName || "" }]} data={delayedTasks} rowKey={(r) => r.taskId} />
        </Section>
      </div>
    </div>
  );
}

// ---------------------- Main App ----------------------
export default function App() {
  const [user, setUser] = useState(null);
  const [active, setActive] = useState("dashboard");
  const { data: users } = useFetchList("/users", [user]);
  const { data: environments } = useFetchList("/environments", [user]);
  const { data: changes } = useFetchList("/changes", [user]);
  const { data: milestones } = useFetchList("/milestones", [user]);
  const [tasksRefreshSignal, setTasksRefreshSignal] = useState(0);

  const main = () => {
    switch (active) {
      case "dashboard": return <DashboardPage />;
      case "projects": return (
        <ProjectsPage
          users={users}
          changes={changes}
          milestones={milestones}
          tasksRefreshSignal={tasksRefreshSignal}
          setTasksRefreshSignal={setTasksRefreshSignal}
        />
      );
      case "code": return <CodePackagesPage environments={environments} changes={changes} />;
      case "env": return <EnvironmentsPage />;
      case "milestone": return <MilestonesPage />;
      case "change": return <ChangesPage environments={environments} tasks={useFetchList("/tasks", [active]).data} />;
      case "users": return user?.role === "ADMIN" ? <UsersPage /> : <div style={{ color: "#991b1b" }}>Admins only.</div>;
      case "uploads": return <UploadsPage />;
      default: return <DashboardPage />;
    }
  };

  if (!user) return <Login onLogin={setUser} />;

  return (
    <Shell user={user} onLogout={() => setUser(null)} active={active} setActive={setActive}>
      {main()}
    </Shell>
  );
}
